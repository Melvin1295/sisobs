(function(){
    var app = angular.module('ubigeos',[
        'ngRoute',
        //'btford.socket-io',
        'ngSanitize',
        'ubigeos.controllers',
        'crud.services',
        'routes',
        'ui.bootstrap'
    ]);
})();